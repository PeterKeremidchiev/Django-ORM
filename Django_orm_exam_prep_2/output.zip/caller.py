import os
import django


# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Profile, Product, Order
from django.db.models import Q, Count


# Create and run your queries within functions

def get_profiles(search_string=None):
    if search_string is None:
        return ''
    query_full_name = Q(full_name__icontains=search_string)
    query_email = Q(email__icontains=search_string)
    query_phone_number = Q(phone_number__icontains=search_string)

    profiles = (Profile.objects.annotate(num_profile_orders=Count('profile_orders'))
                .filter(query_full_name | query_email | query_phone_number)
                .order_by("full_name"))
    if not profiles:
        return ''

    result = []
    for profile in profiles:
        result.append(f"Profile: {profile.full_name}, email: {profile.email}, "
                      f"phone number: {profile.phone_number}, orders: {profile.num_profile_orders}")

    return "\n".join(result)

def get_loyal_profiles():
    profiles = Profile.objects.get_regular_customers()

    if not profiles:
        return ''
    result = [f"Profile: {profile.full_name}, orders: {profile.num_of_orders}" for profile in profiles]

    return "\n".join(result)

def get_last_sold_products():
    last_order = Order.objects.all().last()
    products = last_order.products.all()

    if last_order is None or not last_order.products.exists():
        return ""
    # list_of_products = ", ".join(product.name for product in products)
    # return f'Last sold products: {list_of_products}'
    product_names = [product.name for product in products]

    return f"Last sold products: {', '.join(product_names)}"



